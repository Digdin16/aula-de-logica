﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appcauculator
{
    public partial class Frmcauculadora : Form
    {
        public Frmcauculadora()
        {
            InitializeComponent(); MessageBox.Show("Você abriu a cauculadora");
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou ÷");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou AC");
        }

        private void btnigual_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou igual");
        }

        private void btnvirgula_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou vírgula");
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 0");
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 1");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 3");
        }

        private void btnmais_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou +");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 5");
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 6");
        }

        private void btnmenos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou -");
        }

        private void btnmaismenos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou +/-");
        }

        private void btnporcentagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou %");
        }

        private void txtvisor_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("nao é pra escrever akikct");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 9");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 8");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você apertou 7");
        }
    }
}
