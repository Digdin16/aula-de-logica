﻿namespace Appcauculator
{
    partial class Frmcauculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmcauculadora));
            this.txtvisor = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnvirgula = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btnmais = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnmultiplicaçao = new System.Windows.Forms.Button();
            this.btndivisao = new System.Windows.Forms.Button();
            this.btnac = new System.Windows.Forms.Button();
            this.btnmaismenos = new System.Windows.Forms.Button();
            this.btnporcentagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtvisor
            // 
            this.txtvisor.Font = new System.Drawing.Font("Microsoft Sans Serif", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvisor.Location = new System.Drawing.Point(9, 35);
            this.txtvisor.Name = "txtvisor";
            this.txtvisor.Size = new System.Drawing.Size(317, 83);
            this.txtvisor.TabIndex = 0;
            this.txtvisor.TextChanged += new System.EventHandler(this.txtvisor_TextChanged);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(12, 342);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(55, 54);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(85, 342);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(55, 54);
            this.btn2.TabIndex = 2;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(155, 342);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(63, 54);
            this.btn3.TabIndex = 3;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn0
            // 
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(12, 421);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(128, 48);
            this.btn0.TabIndex = 4;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btnvirgula
            // 
            this.btnvirgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvirgula.Location = new System.Drawing.Point(155, 421);
            this.btnvirgula.Name = "btnvirgula";
            this.btnvirgula.Size = new System.Drawing.Size(63, 48);
            this.btnvirgula.TabIndex = 5;
            this.btnvirgula.Text = ",";
            this.btnvirgula.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnvirgula.UseVisualStyleBackColor = true;
            this.btnvirgula.Click += new System.EventHandler(this.btnvirgula_Click);
            // 
            // btnigual
            // 
            this.btnigual.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnigual.Location = new System.Drawing.Point(237, 421);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(75, 48);
            this.btnigual.TabIndex = 6;
            this.btnigual.Text = "=";
            this.btnigual.UseVisualStyleBackColor = true;
            this.btnigual.Click += new System.EventHandler(this.btnigual_Click);
            // 
            // btnmais
            // 
            this.btnmais.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmais.Location = new System.Drawing.Point(237, 342);
            this.btnmais.Name = "btnmais";
            this.btnmais.Size = new System.Drawing.Size(75, 54);
            this.btnmais.TabIndex = 7;
            this.btnmais.Text = "+";
            this.btnmais.UseVisualStyleBackColor = true;
            this.btnmais.Click += new System.EventHandler(this.btnmais_Click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(12, 282);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(55, 54);
            this.btn4.TabIndex = 8;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(85, 282);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(55, 54);
            this.btn5.TabIndex = 9;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(155, 282);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(63, 54);
            this.btn6.TabIndex = 10;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btnmenos
            // 
            this.btnmenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmenos.Location = new System.Drawing.Point(237, 282);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(75, 54);
            this.btnmenos.TabIndex = 11;
            this.btnmenos.Text = "-";
            this.btnmenos.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnmenos.UseVisualStyleBackColor = true;
            this.btnmenos.Click += new System.EventHandler(this.btnmenos_Click);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(12, 222);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(55, 54);
            this.btn7.TabIndex = 12;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(85, 222);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(55, 54);
            this.btn8.TabIndex = 13;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(155, 222);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(63, 54);
            this.btn9.TabIndex = 14;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btnmultiplicaçao
            // 
            this.btnmultiplicaçao.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmultiplicaçao.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnmultiplicaçao.Location = new System.Drawing.Point(237, 222);
            this.btnmultiplicaçao.Name = "btnmultiplicaçao";
            this.btnmultiplicaçao.Size = new System.Drawing.Size(75, 54);
            this.btnmultiplicaçao.TabIndex = 15;
            this.btnmultiplicaçao.Text = "×";
            this.btnmultiplicaçao.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnmultiplicaçao.UseVisualStyleBackColor = true;
            // 
            // btndivisao
            // 
            this.btndivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndivisao.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btndivisao.Location = new System.Drawing.Point(237, 162);
            this.btndivisao.Name = "btndivisao";
            this.btndivisao.Size = new System.Drawing.Size(75, 54);
            this.btndivisao.TabIndex = 17;
            this.btndivisao.Text = "÷";
            this.btndivisao.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btndivisao.UseVisualStyleBackColor = true;
            this.btndivisao.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnac
            // 
            this.btnac.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnac.Location = new System.Drawing.Point(12, 162);
            this.btnac.Name = "btnac";
            this.btnac.Size = new System.Drawing.Size(55, 54);
            this.btnac.TabIndex = 18;
            this.btnac.Text = "AC";
            this.btnac.UseVisualStyleBackColor = true;
            this.btnac.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnmaismenos
            // 
            this.btnmaismenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmaismenos.Location = new System.Drawing.Point(85, 162);
            this.btnmaismenos.Name = "btnmaismenos";
            this.btnmaismenos.Size = new System.Drawing.Size(55, 54);
            this.btnmaismenos.TabIndex = 19;
            this.btnmaismenos.Text = "±";
            this.btnmaismenos.UseVisualStyleBackColor = true;
            this.btnmaismenos.Click += new System.EventHandler(this.btnmaismenos_Click);
            // 
            // btnporcentagem
            // 
            this.btnporcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnporcentagem.Location = new System.Drawing.Point(155, 162);
            this.btnporcentagem.Name = "btnporcentagem";
            this.btnporcentagem.Size = new System.Drawing.Size(63, 54);
            this.btnporcentagem.TabIndex = 20;
            this.btnporcentagem.Text = "%";
            this.btnporcentagem.UseVisualStyleBackColor = true;
            this.btnporcentagem.Click += new System.EventHandler(this.btnporcentagem_Click);
            // 
            // Frmcauculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Appcauculator.Properties.Resources.NeBIGw;
            this.ClientSize = new System.Drawing.Size(338, 481);
            this.Controls.Add(this.btnporcentagem);
            this.Controls.Add(this.btnmaismenos);
            this.Controls.Add(this.btnac);
            this.Controls.Add(this.btndivisao);
            this.Controls.Add(this.btnmultiplicaçao);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btnmais);
            this.Controls.Add(this.btnigual);
            this.Controls.Add(this.btnvirgula);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txtvisor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frmcauculadora";
            this.Text = "Cauculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtvisor;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnvirgula;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btnmais;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnmultiplicaçao;
        private System.Windows.Forms.Button btndivisao;
        private System.Windows.Forms.Button btnac;
        private System.Windows.Forms.Button btnmaismenos;
        private System.Windows.Forms.Button btnporcentagem;
    }
}

